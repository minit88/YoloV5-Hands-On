# inseaoutsea2 > 2022-10-29 12:18pm
https://universe.roboflow.com/pknu-nzio7/inseaoutsea2

Provided by a Roboflow user
License: CC BY 4.0

